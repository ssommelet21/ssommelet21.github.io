`npm i -g json-server`

`json-server --w src/assets/db.json --port 3003`
